# PRODIGY_AD_02
Embark on a journey of productivity with this comprehensive To-Do List App on Android! Seamlessly blending task management with basic arithmetic operations, this app is your go-to for staying organized and efficient.  💡 Key Features:  Task Management: Add, edit, and check off tasks with ease.
